import '../css/simple-anime.css';

import SimpleAnime from '../js/simple-anime.js';
window.SimpleAnime = SimpleAnime;